export const startLoading = () => ({ type: 'LOADING' });

export const endLoading = () => ({ type: 'NOT_LOADING' });
