export const addFilter = type => ({ type });
