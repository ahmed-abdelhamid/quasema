export const saveAllOffers = offers => ({ type: 'SAVE_ALL_OFFERS', offers });

// export const saveChangeCompanyState = company => ({ type: 'CHANGE_STATE', company });

export const removeAllOffers = () => ({ type: 'REMOVE_ALL_OFFERS' });
