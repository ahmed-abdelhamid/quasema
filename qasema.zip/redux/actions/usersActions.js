export const saveAllUsers = users => ({ type: 'SAVE_ALL_USERS', users });

export const removeAllUsers = () => ({ type: 'REMOVE_ALL_USERS' });
