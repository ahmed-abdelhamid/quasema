export const saveAllReports = reports => ({ type: 'SAVE_ALL_REPORTS', reports });

export const removeAllReports = () => ({ type: 'REMOVE_ALL_REPORTS' });
