module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+NUC":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/router/rewrite-url-for-export");

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("ShIx");


/***/ }),

/***/ "0Bsm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault2 = __webpack_require__("KI45");

var _classCallCheck2 = _interopRequireDefault2(__webpack_require__("0iUn"));

var _createClass2 = _interopRequireDefault2(__webpack_require__("sLSF"));

var _possibleConstructorReturn2 = _interopRequireDefault2(__webpack_require__("MI3g"));

var _getPrototypeOf2 = _interopRequireDefault2(__webpack_require__("a7VT"));

var _inherits2 = _interopRequireDefault2(__webpack_require__("Tit0"));

var _interopRequireDefault = __webpack_require__("KI45");

exports.__esModule = true;
exports["default"] = withRouter;

var _extends2 = _interopRequireDefault(__webpack_require__("htGi"));

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _propTypes = _interopRequireDefault(__webpack_require__("rf6O"));

function withRouter(ComposedComponent) {
  var WithRouteWrapper =
  /*#__PURE__*/
  function (_react$default$Compon) {
    (0, _inherits2["default"])(WithRouteWrapper, _react$default$Compon);

    function WithRouteWrapper() {
      var _this;

      (0, _classCallCheck2["default"])(this, WithRouteWrapper);
      _this = (0, _possibleConstructorReturn2["default"])(this, (0, _getPrototypeOf2["default"])(WithRouteWrapper).apply(this, arguments));
      _this.context = void 0;
      return _this;
    }

    (0, _createClass2["default"])(WithRouteWrapper, [{
      key: "render",
      value: function render() {
        return _react["default"].createElement(ComposedComponent, (0, _extends2["default"])({
          router: this.context.router
        }, this.props));
      }
    }]);
    return WithRouteWrapper;
  }(_react["default"].Component);

  WithRouteWrapper.displayName = void 0;
  WithRouteWrapper.getInitialProps = void 0;
  WithRouteWrapper.contextTypes = {
    router: _propTypes["default"].object
  };
  WithRouteWrapper.getInitialProps = ComposedComponent.getInitialProps;

  if (false) { var name; }

  return WithRouteWrapper;
}

/***/ }),

/***/ "0Jp5":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogTitle");

/***/ }),

/***/ "0LMq":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/List");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1imS":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CircularProgress");

/***/ }),

/***/ "2I19":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return saveAllCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return saveChangeCompanyState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return removeAllCompanies; });
var saveAllCompanies = function saveAllCompanies(companies) {
  return {
    type: 'SAVE_ALL',
    companies: companies
  };
};
var saveChangeCompanyState = function saveChangeCompanyState(company) {
  return {
    type: 'CHANGE_STATE',
    company: company
  };
};
var removeAllCompanies = function removeAllCompanies() {
  return {
    type: 'REMOVE_ALL'
  };
};

/***/ }),

/***/ "30mr":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableBody");

/***/ }),

/***/ "3i/4":
/***/ (function(module, exports) {

module.exports = require("next-cookies");

/***/ }),

/***/ "4Ioi":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  TITLE: 'قسيمه',
  HEADER_TITLE: 'قسيمه',
  HOME: 'الرئيسية',
  CLIENTS: 'مقدمى العروض',
  USERS: 'مستخدمى التطبيق',
  OFFERS: 'العروض',
  REPORTS: 'البلاغات',
  CHANGE_PASSWORD: 'تغيير كلمة المرور',
  LOGOUT: 'تسجيل الخروج',
  REQUIRED_FILED: 'حقل إلزامى',
  LOGIN: 'تسجيل الدخول',
  EMAIL_OR_PHONE: 'البريد الألكترونى أو رقم الجوال',
  PASSWORD: 'كلمة المرور',
  CREDENTIALS_ERROR: 'خطأ فى اسم المستخدم أو كلمة المرور',
  LOADING: 'جارى التحميل',
  PENDING: 'فى انتظار التفعيل',
  ACTIVE: 'مقدمى العروض النشيطين',
  INACTIVE: 'مقدمى العروض الغير نشيطين',
  PROFIT: 'شركات ربحية',
  NON_PROFIT: 'جمعيات خيرية',
  NAME: 'الاسم',
  MOI_NUMBER: 'رقم السجل التجارى',
  CITY: 'المدينة',
  MOBILE_NUMBER: 'رقم الجوال',
  NOTHING: 'لا يوجد',
  SHOW_DETAILS: 'عرض التفاصيل',
  ACTIVATE: 'تفعيل',
  DEACTIVATE: 'تعطيل',
  WALLET: 'المحفظة',
  EMAIL: 'البريد الالكترونى',
  WEB_URL: 'الموقع الاكترونى',
  TWITTER: 'حساب تويتر',
  INSTGRAM: 'حساب الانستجرام',
  DESCRIPTION: 'نبذة عن مقدم العرض',
  LOCATION: 'الموقع على الخريطة',
  NO_WALLET_DETAILS: 'لا يوجد رصيد بالمحظة',
  CURRENT_BALANCE: 'الرصيد الحالى',
  TOTAL_PROFIT: 'مجموع الارباح',
  COMISSION: 'عمولة قسيمة',
  TRANSFERRED_PROFIT: 'الارباح المحولة مسبقا',
  WITHDRAW: 'اجراء تحويل',
  LOWER_ZERO: 'يجب ان يكون المبلغ المحول اكثر من صفر',
  WITHDRAW_SUCCESS: 'تمت عملية التحويل بنجاح',
  FAILED_WITHDRAW: 'فشل فى عملية التحويل. يرجى إعادة المحاولة',
  PURCHASES: 'المشتريات',
  NO_ORDERS: 'لا يوجد مشتريات لهذا المستخدم',
  QUASEMA_NAME: 'اسم القسيمة',
  QUASEMA_PROVIDER_NAME: 'اسم مقدم القسيمة',
  QUASEMA_TYPE: 'نوع القسيمة',
  QUASEMA_COST: 'مبلغ القسيمة',
  QUASEMA_AMOUNT: 'عدد القسائم التى تم شرائها',
  QUASEMA_ORDER_NO: 'رقم الطلب',
  QUASEMA_ORDER_DATE: 'تاريخ الطلب',
  labelDisplayedRows: function labelDisplayedRows(_ref) {
    var from = _ref.from,
        to = _ref.to,
        count = _ref.count;
    return "".concat(from, " - ").concat(to, " \u0645\u0646 \u0627\u062C\u0645\u0627\u0644\u0649 ").concat(count);
  },
  ROWS_PER_PAGE: 'عدد الوحدات بالصفحة',
  USERNAME: 'اسم المستخدم',
  OFFER_NAME: 'اسم العرض',
  OFFER_PROVIDER_NAME: 'اسم مقدم العرض',
  OFFER_PRICE: 'السعر',
  OFFER_RATE: 'التقييم',
  SHOW_IMAGES: 'عرض الصور',
  FORGET_PASSWORD: 'نسيت كلمة المرور',
  RESET_PASSWORD: 'استعادة كلمة المرور',
  WRONG_EMAIL: 'البريد الالكترونى غير صحيح',
  OLD_PASSWORD: 'كلمة المرور الحالية',
  NEW_PASSWORD: 'كلمة المرور الجديدة',
  WRONG_OLD_PASSWORD: 'كلمة المرور الحالية غير صحيحة',
  NO_OFFERS: 'لا يوجد عروض',
  CATEGORY: 'القسم',
  ADDRESS: 'العنوان',
  OFFER_TYPE: 'نوع العرض',
  AMOUNT: 'العدد',
  EXPIRY: 'صلاحية العرض',
  ILLUSTRATION: 'شرح تفاصيل العرض',
  WHY: 'مميزات العرض',
  IMAGES_OFFERS: 'الصور الخاصة بالعرض',
  BEST_OFFERS: 'أقوى العروض',
  ALL: 'الكل',
  HOUSING: 'شاليهات ومنتجعات',
  COFFEESHOPS: 'مطاعم ومقاهى',
  CLINICS: 'مراكز وعيادات',
  TRAVEL: 'سياحة وسفر',
  BEAUTY_CENTERS: 'مراكز تجميل',
  SHOPPING: 'تسوق',
  FAMILIES: 'أسر منتجة',
  COURSES: 'دورات',
  OTHERS: 'أخري',
  BEST_SALES: 'الأكثر مبيعا',
  BEST_RATES: 'الأكثر تقييما',
  LESS_THAN_THIRTY: 'أقل من 30 ريال',
  CHARITY: 'خيرى',
  CONDITIONS: 'الشروط'
});

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "50L+":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Cancel");

/***/ }),

/***/ "5Uuq":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getOwnPropertyDescriptor = __webpack_require__("Jo+v");

var _Object$defineProperty = __webpack_require__("hfKm");

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  } else {
    var newObj = {};

    if (obj != null) {
      for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          var desc = _Object$defineProperty && _Object$getOwnPropertyDescriptor ? _Object$getOwnPropertyDescriptor(obj, key) : {};

          if (desc.get || desc.set) {
            _Object$defineProperty(newObj, key, desc);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
    }

    newObj["default"] = obj;
    return newObj;
  }
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "6Yxu":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Tab");

/***/ }),

/***/ "7hht":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Email");

/***/ }),

/***/ "7s44":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/FormControlLabel");

/***/ }),

/***/ "9Pu4":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "Aet0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("9Pu4");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0Jp5");
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("EmCc");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("gXGL");
/* harmony import */ var mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4__);





var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__["makeStyles"])(function (theme) {
  return {
    title: {
      textAlign: 'center'
    },
    closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500]
    }
  };
});

var DialogTitle = function DialogTitle(_ref) {
  var children = _ref.children,
      onClose = _ref.onClose;
  var classes = useStyles();
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2___default.a, {
    className: classes.title
  }, children, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3___default.a, {
    className: classes.closeButton,
    onClick: onClose
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4___default.a, null)));
};

/* harmony default export */ __webpack_exports__["a"] = (DialogTitle);

/***/ }),

/***/ "Ai9N":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableCell");

/***/ }),

/***/ "BUv7":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Pencil");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "BjFw":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Table");

/***/ }),

/***/ "Cg2A":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("y6vh");

/***/ }),

/***/ "Dl9a":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Twitter");

/***/ }),

/***/ "EmCc":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/IconButton");

/***/ }),

/***/ "GLYF":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemIcon");

/***/ }),

/***/ "H20q":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/CheckboxMarkedCircleOutline");

/***/ }),

/***/ "H5EN":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return getPendingCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getActiveCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getInactiveCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return changeCompanyState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return filterCompanies; });
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ln6h");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("O40h");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);



var getPendingCompanies =
/*#__PURE__*/
function () {
  var _ref = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getallcompany/", true, "/", false));

          case 2:
            response = _context.sent;
            return _context.abrupt("return", response.data);

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getPendingCompanies() {
    return _ref.apply(this, arguments);
  };
}();
var getActiveCompanies =
/*#__PURE__*/
function () {
  var _ref2 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getallcompany/", false, "/", false));

          case 2:
            response = _context2.sent;
            return _context2.abrupt("return", response.data);

          case 4:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function getActiveCompanies() {
    return _ref2.apply(this, arguments);
  };
}();
var getInactiveCompanies =
/*#__PURE__*/
function () {
  var _ref3 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getallcompany/", false, "/", true));

          case 2:
            response = _context3.sent;
            return _context3.abrupt("return", response.data);

          case 4:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function getInactiveCompanies() {
    return _ref3.apply(this, arguments);
  };
}();
var changeCompanyState =
/*#__PURE__*/
function () {
  var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4(id, activity, pending) {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/changecompanystatus/").concat(id, "/").concat(activity, "/").concat(pending));

          case 2:
            response = _context4.sent;
            return _context4.abrupt("return", response.data);

          case 4:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function changeCompanyState(_x, _x2, _x3) {
    return _ref4.apply(this, arguments);
  };
}();
var filterCompanies = function filterCompanies(companies, filters) {
  switch (filters.filterClientsBy) {
    case 'profit':
      return companies.filter(function (_ref5) {
        var company = _ref5.company;
        return !company.isNonProfit;
      });

    case 'nonProfit':
      return companies.filter(function (_ref6) {
        var company = _ref6.company;
        return company.isNonProfit;
      });

    default:
      return companies;
  }
};

/***/ }),

/***/ "IbbU":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TextField");

/***/ }),

/***/ "J3/a":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "JQ2V":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "LK70":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("MCme");
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("EmCc");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0LMq");
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("c25J");
/* harmony import */ var _material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("GLYF");
/* harmony import */ var _material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("W+03");
/* harmony import */ var _material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("fEgT");
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("iTUb");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("JQ2V");
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("7hht");
/* harmony import */ var mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("ncp3");
/* harmony import */ var mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("eaXY");
/* harmony import */ var mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("nFSa");
/* harmony import */ var mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("mxtS");
/* harmony import */ var mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("Dl9a");
/* harmony import */ var mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("eoIS");
/* harmony import */ var mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("BUv7");
/* harmony import */ var mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("vW2u");
/* harmony import */ var mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__("4Ioi");
/* harmony import */ var _DialogTitle__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__("Aet0");






















var ShowDetailsDialog = function ShowDetailsDialog(_ref) {
  var onClose = _ref.onClose,
      open = _ref.open,
      client = _ref.client;
  var LIST_ITEMS = [{
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].EMAIL,
    value: client.email,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].MOBILE_NUMBER,
    value: client.mobile,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].MOI_NUMBER,
    value: client.moi_Id,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].CITY,
    value: client.city,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].WEB_URL,
    value: client.webUrl,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].TWITTER,
    value: client.twitter,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].INSTGRAM,
    value: client.instgram,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].DESCRIPTION,
    value: client.description,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17___default.a, null)
  }];

  var renderLocationIcon = function renderLocationIcon() {
    if (!client.lat && !client.lag) {
      return _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].NOTHING;
    }

    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1___default.a, {
      href: "https://www.google.com/maps/search/?api=1&query=".concat(client.lat, ",").concat(client.lag),
      target: "_blank"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2___default.a, {
      color: "secondary",
      style: {
        padding: 0
      }
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18___default.a, null)));
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7___default.a, {
    onClose: onClose,
    open: open,
    fullWidth: true
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_DialogTitle__WEBPACK_IMPORTED_MODULE_20__[/* default */ "a"], {
    onClose: onClose
  }, client.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8___default.a, {
    dividers: true
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_3___default.a, null, LIST_ITEMS.map(function (_ref2) {
    var name = _ref2.name,
        value = _ref2.value,
        icon = _ref2.icon;
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4___default.a, {
      key: name
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default.a, null, icon), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
      container: true,
      spacing: 2
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
      item: true,
      sm: 5
    }, name, ":"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
      item: true,
      sm: 7
    }, value))));
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18___default.a, null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
    container: true,
    spacing: 2
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
    item: true,
    sm: 5
  }, _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].LOCATION, ":"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
    item: true,
    sm: 7
  }, renderLocationIcon())))))));
};

/* harmony default export */ __webpack_exports__["a"] = (ShowDetailsDialog);

/***/ }),

/***/ "LX0d":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Xql+");

/***/ }),

/***/ "MCme":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Link");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "NCjo":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/SackPercent");

/***/ }),

/***/ "No08":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return addFilter; });
var addFilter = function addFilter(type) {
  return {
    type: type
  };
};

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "R2Q7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "S++P":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9Pu4");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["a"] = (Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])({
  root: {
    flexGrow: 1,
    maxWidth: 500
  },
  title: {
    fontSize: 50,
    marginBottom: 25
  },
  info: {
    fontSize: 25,
    paddingTop: 10
  },
  paper: {
    minHeight: '30vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  }
}));

/***/ }),

/***/ "SJC6":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Tabs");

/***/ }),

/***/ "SMlj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return redirectOnError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return withAuthSync; });
/* unused harmony export auth */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return changePassword; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return forgetPassword; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("zrwo");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("AT/M");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("vYYK");
/* harmony import */ var _babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("Cg2A");
/* harmony import */ var _babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("ln6h");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("O40h");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("3i/4");
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_cookies__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("vmXh");
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_15__);















 // Redirect on Error

var redirectOnError = function redirectOnError(ctx) {
   false ? undefined : ctx.res.writeHead(302, {
    location: '/login'
  }).end();
}; // Login Admin

var login =
/*#__PURE__*/
function () {
  var _ref2 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee(_ref) {
    var token;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            token = _ref.token;
            js_cookie__WEBPACK_IMPORTED_MODULE_15___default.a.set('token', token, {
              expires: 1
            });
            next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/clients');

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function login(_x) {
    return _ref2.apply(this, arguments);
  };
}(); // Logout Admin

var logout = function logout() {
  js_cookie__WEBPACK_IMPORTED_MODULE_15___default.a.remove('token'); // To support logging out from all windows

  window.localStorage.setItem('logout', _babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8___default()());
  next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/login');
}; // Gets the display name of JSX component for dev tools

var getDisplayName = function getDisplayName(Component) {
  return Component.displayName || Component.name || 'Component';
}; // Check if User is Authorized or Not


var withAuthSync = function withAuthSync(WrappedComponent) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_Component) {
    Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__["default"])(_class, _Component);

    Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__["default"])(_class, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
        /*#__PURE__*/
        _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee2(ctx) {
          var token, componentProps;
          return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  token = auth(ctx);
                  _context2.t0 = WrappedComponent.getInitialProps;

                  if (!_context2.t0) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return WrappedComponent.getInitialProps(ctx);

                case 5:
                  _context2.t0 = _context2.sent;

                case 6:
                  componentProps = _context2.t0;
                  return _context2.abrupt("return", Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, componentProps, {
                    token: token
                  }));

                case 8:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        function getInitialProps(_x2) {
          return _getInitialProps.apply(this, arguments);
        }

        return getInitialProps;
      }()
    }]);

    function _class(props) {
      var _this;

      Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, _class);

      _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(_class).call(this, props));
      _this.syncLogout = _this.syncLogout.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(_this));
      return _this;
    }

    Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__["default"])(_class, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        window.addEventListener('storage', this.syncLogout);
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        window.removeEventListener('storage', this.syncLogout);
        window.localStorage.removeItem('logout');
      }
    }, {
      key: "syncLogout",
      value: function syncLogout(event) {
        if (event.key === 'logout') {
          next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/login');
        }
      }
    }, {
      key: "render",
      value: function render() {
        return react__WEBPACK_IMPORTED_MODULE_11___default.a.createElement(WrappedComponent, this.props);
      }
    }]);

    return _class;
  }(react__WEBPACK_IMPORTED_MODULE_11__["Component"]), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(_class, "displayName", "withAuthSync(".concat(getDisplayName(WrappedComponent), ")")), _temp;
};
var auth = function auth(ctx) {
  var _nextCookie = next_cookies__WEBPACK_IMPORTED_MODULE_14___default()(ctx),
      token = _nextCookie.token;
  /*
   * This happens on server only, ctx.req is available means it's being
   * rendered on server. If we are on server and token is not available,
   * means user is not logged in.
   */


  if (ctx.req && !token) {
    ctx.res.writeHead(302, {
      location: '/login'
    });
    ctx.res.end();
    return;
  } // We already checked for server. This should only happen in client


  if (!token) {
    next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/login');
    return token;
  }
}; // Change Password

var changePassword =
/*#__PURE__*/
function () {
  var _ref3 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee3(id, newPassword, oldPassword) {
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_12___default.a.put("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/admin/restorepass"), {
              userId: id,
              oldPassword: oldPassword,
              newPassword: newPassword
            });

          case 2:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function changePassword(_x3, _x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}(); // Forget Password

var forgetPassword =
/*#__PURE__*/
function () {
  var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee4(email) {
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_12___default.a.put("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/admin/forgotpassword"), {
              email: email
            });

          case 2:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function forgetPassword(_x6) {
    return _ref4.apply(this, arguments);
  };
}();

/***/ }),

/***/ "ShIx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__("h74D");

// EXTERNAL MODULE: external "next-cookies"
var external_next_cookies_ = __webpack_require__("3i/4");
var external_next_cookies_default = /*#__PURE__*/__webpack_require__.n(external_next_cookies_);

// EXTERNAL MODULE: external "@material-ui/core/Paper"
var Paper_ = __webpack_require__("qt1I");
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);

// EXTERNAL MODULE: external "@material-ui/core/Container"
var Container_ = __webpack_require__("Uynj");
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);

// EXTERNAL MODULE: external "@material-ui/core/Typography"
var Typography_ = __webpack_require__("UVoM");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);

// EXTERNAL MODULE: external "@material-ui/core/Tabs"
var Tabs_ = __webpack_require__("SJC6");
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs_);

// EXTERNAL MODULE: external "@material-ui/core/Tab"
var Tab_ = __webpack_require__("6Yxu");
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab_);

// EXTERNAL MODULE: external "mdi-material-ui/Timer"
var Timer_ = __webpack_require__("zTfa");
var Timer_default = /*#__PURE__*/__webpack_require__.n(Timer_);

// EXTERNAL MODULE: external "mdi-material-ui/Cancel"
var Cancel_ = __webpack_require__("50L+");
var Cancel_default = /*#__PURE__*/__webpack_require__.n(Cancel_);

// EXTERNAL MODULE: external "mdi-material-ui/CheckboxMarkedCircleOutline"
var CheckboxMarkedCircleOutline_ = __webpack_require__("H20q");
var CheckboxMarkedCircleOutline_default = /*#__PURE__*/__webpack_require__.n(CheckboxMarkedCircleOutline_);

// EXTERNAL MODULE: ./styles/clientsPage.js
var clientsPage = __webpack_require__("S++P");

// EXTERNAL MODULE: ./translations/arabicTranslation.js
var arabicTranslation = __webpack_require__("4Ioi");

// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__("SMlj");

// EXTERNAL MODULE: ./utils/clients.js
var utils_clients = __webpack_require__("H5EN");

// EXTERNAL MODULE: ./redux/actions/clientsActions.js
var clientsActions = __webpack_require__("2I19");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: external "@material-ui/core/Table"
var Table_ = __webpack_require__("BjFw");
var Table_default = /*#__PURE__*/__webpack_require__.n(Table_);

// EXTERNAL MODULE: external "@material-ui/core/TableBody"
var TableBody_ = __webpack_require__("30mr");
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody_);

// EXTERNAL MODULE: external "@material-ui/core/TableCell"
var TableCell_ = __webpack_require__("Ai9N");
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell_);

// EXTERNAL MODULE: external "@material-ui/core/TableHead"
var TableHead_ = __webpack_require__("TWtx");
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead_);

// EXTERNAL MODULE: external "@material-ui/core/TableRow"
var TableRow_ = __webpack_require__("iDDF");
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow_);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// EXTERNAL MODULE: external "@material-ui/core/IconButton"
var IconButton_ = __webpack_require__("EmCc");
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);

// EXTERNAL MODULE: external "@material-ui/core/Tooltip"
var Tooltip_ = __webpack_require__("vF8F");
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip_);

// EXTERNAL MODULE: external "mdi-material-ui/AccountCardDetails"
var AccountCardDetails_ = __webpack_require__("St2x");
var AccountCardDetails_default = /*#__PURE__*/__webpack_require__.n(AccountCardDetails_);

// EXTERNAL MODULE: external "mdi-material-ui/SackPercent"
var SackPercent_ = __webpack_require__("NCjo");
var SackPercent_default = /*#__PURE__*/__webpack_require__.n(SackPercent_);

// EXTERNAL MODULE: external "mdi-material-ui/Wallet"
var Wallet_ = __webpack_require__("fdDk");
var Wallet_default = /*#__PURE__*/__webpack_require__.n(Wallet_);

// EXTERNAL MODULE: ./components/ShowClientDetails.js
var ShowClientDetails = __webpack_require__("LK70");

// EXTERNAL MODULE: ./components/WalletDetails.js + 2 modules
var WalletDetails = __webpack_require__("b5DJ");

// CONCATENATED MODULE: ./components/ClientsTableButtons.js



















var ClientsTableButtons_ClientsTableButons = function ClientsTableButons(_ref) {
  var client = _ref.client,
      saveChangeCompanyState = _ref.saveChangeCompanyState;

  var _useState = Object(external_react_["useState"])(false),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      openClientDetails = _useState2[0],
      setOpenClientDetails = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(false),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      openWallet = _useState4[0],
      setOpenWallet = _useState4[1];

  var activateClient =
  /*#__PURE__*/
  function () {
    var _ref2 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee() {
      return regenerator_default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return Object(utils_clients["a" /* changeCompanyState */])(client.userId, false, false);

            case 2:
              saveChangeCompanyState(client);

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function activateClient() {
      return _ref2.apply(this, arguments);
    };
  }();

  var deactivateClient =
  /*#__PURE__*/
  function () {
    var _ref3 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee2() {
      return regenerator_default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return Object(utils_clients["a" /* changeCompanyState */])(client.userId, true, false);

            case 2:
              saveChangeCompanyState(client);

            case 3:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function deactivateClient() {
      return _ref3.apply(this, arguments);
    };
  }();

  return external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement(Tooltip_default.a, {
    title: arabicTranslation["a" /* default */].SHOW_DETAILS
  }, external_react_default.a.createElement(IconButton_default.a, {
    color: "primary",
    onClick: function onClick() {
      return setOpenClientDetails(true);
    }
  }, external_react_default.a.createElement(AccountCardDetails_default.a, null))), !client.isPanding && external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement(Tooltip_default.a, {
    title: arabicTranslation["a" /* default */].OFFERS
  }, external_react_default.a.createElement("span", null, external_react_default.a.createElement(link_default.a, {
    href: "/offers?id=".concat(client.companyId)
  }, external_react_default.a.createElement(IconButton_default.a, {
    color: "primary"
  }, external_react_default.a.createElement(SackPercent_default.a, null))))), external_react_default.a.createElement(Tooltip_default.a, {
    title: arabicTranslation["a" /* default */].WALLET
  }, external_react_default.a.createElement(IconButton_default.a, {
    color: "primary",
    onClick: function onClick() {
      return setOpenWallet(true);
    }
  }, external_react_default.a.createElement(Wallet_default.a, null)))), (client.isLock || client.isPanding) && external_react_default.a.createElement(Tooltip_default.a, {
    title: arabicTranslation["a" /* default */].ACTIVATE,
    onClick: activateClient
  }, external_react_default.a.createElement(IconButton_default.a, {
    color: "primary"
  }, external_react_default.a.createElement(CheckboxMarkedCircleOutline_default.a, null))), !client.isLock && !client.isPanding && external_react_default.a.createElement(Tooltip_default.a, {
    title: arabicTranslation["a" /* default */].DEACTIVATE,
    onClick: deactivateClient
  }, external_react_default.a.createElement(IconButton_default.a, {
    color: "secondary"
  }, external_react_default.a.createElement(Cancel_default.a, null))), openClientDetails && external_react_default.a.createElement(ShowClientDetails["a" /* default */], {
    open: openClientDetails,
    onClose: function onClose() {
      return setOpenClientDetails(false);
    },
    client: client
  }), openWallet && external_react_default.a.createElement(WalletDetails["a" /* default */], {
    open: openWallet,
    onClose: function onClose() {
      return setOpenWallet(false);
    },
    client: client
  }));
};

var ClientsTableButtons_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    saveChangeCompanyState: function saveChangeCompanyState(company) {
      return dispatch(Object(clientsActions["c" /* saveChangeCompanyState */])(company));
    }
  };
};

/* harmony default export */ var ClientsTableButtons = (Object(external_react_redux_["connect"])(null, ClientsTableButtons_mapDispatchToProps)(ClientsTableButtons_ClientsTableButons));
// CONCATENATED MODULE: ./components/ClientsTable.js












var ClientsTable_ClientsTable = function ClientsTable(_ref) {
  var clients = _ref.clients;
  var classes = Object(clientsPage["a" /* default */])();

  if (clients.length === 0) {
    return external_react_default.a.createElement(Typography_default.a, {
      className: classes.info,
      align: "center",
      gutterBottom: true
    }, arabicTranslation["a" /* default */].NOTHING);
  }

  return external_react_default.a.createElement(Table_default.a, {
    dir: "rtl"
  }, external_react_default.a.createElement(TableHead_default.a, null, external_react_default.a.createElement(TableRow_default.a, null, external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].NAME), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].MOI_NUMBER), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].CITY), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].MOBILE_NUMBER), external_react_default.a.createElement(TableCell_default.a, null))), external_react_default.a.createElement(TableBody_default.a, null, clients.map(function (_ref2) {
    var user = _ref2.user,
        company = _ref2.company;
    return external_react_default.a.createElement(TableRow_default.a, {
      key: user.userId
    }, external_react_default.a.createElement(TableCell_default.a, null, user.name), external_react_default.a.createElement(TableCell_default.a, null, company.moi_Id), external_react_default.a.createElement(TableCell_default.a, null, user.city), external_react_default.a.createElement(TableCell_default.a, null, user.mobile), external_react_default.a.createElement(TableCell_default.a, {
      align: "center"
    }, external_react_default.a.createElement(ClientsTableButtons, {
      client: Object(objectSpread["a" /* default */])({}, user, company)
    })));
  })));
};

/* harmony default export */ var components_ClientsTable = (ClientsTable_ClientsTable);
// EXTERNAL MODULE: external "@material-ui/core/FormControlLabel"
var FormControlLabel_ = __webpack_require__("7s44");
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_);

// EXTERNAL MODULE: external "@material-ui/core/Checkbox"
var Checkbox_ = __webpack_require__("r6Lb");
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_);

// EXTERNAL MODULE: ./redux/actions/filtersActions.js
var filtersActions = __webpack_require__("No08");

// CONCATENATED MODULE: ./components/ClientsFilters.js







var ClientsFilters_ClientsFilters = function ClientsFilters(_ref) {
  var filterBy = _ref.filterBy,
      addFilter = _ref.addFilter;

  var handleFilter = function handleFilter(event, type) {
    if (event.target.checked) {
      addFilter(type);
    } else {
      addFilter('ALL');
    }
  };

  return external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement(FormControlLabel_default.a, {
    control: external_react_default.a.createElement(Checkbox_default.a, {
      checked: filterBy === 'profit',
      onChange: function onChange(event) {
        return handleFilter(event, 'PROFIT');
      }
    }),
    label: arabicTranslation["a" /* default */].PROFIT
  }), external_react_default.a.createElement(FormControlLabel_default.a, {
    control: external_react_default.a.createElement(Checkbox_default.a, {
      checked: filterBy === 'nonProfit',
      onChange: function onChange(event) {
        return handleFilter(event, 'NON_PROFIT');
      }
    }),
    label: arabicTranslation["a" /* default */].NON_PROFIT
  }));
};

var ClientsFilters_mapStateToProps = function mapStateToProps(_ref2) {
  var filters = _ref2.filters;
  return {
    filterBy: filters.filterClientsBy
  };
};

var ClientsFilters_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    addFilter: function addFilter(type) {
      return dispatch(Object(filtersActions["a" /* addFilter */])(type));
    }
  };
};

/* harmony default export */ var components_ClientsFilters = (Object(external_react_redux_["connect"])(ClientsFilters_mapStateToProps, ClientsFilters_mapDispatchToProps)(ClientsFilters_ClientsFilters));
// CONCATENATED MODULE: ./pages/clients.js





 // Material UI Imports

















var clients_Clients = function Clients(_ref) {
  var clients = _ref.clients,
      removeAllCompanies = _ref.removeAllCompanies,
      saveAllCompanies = _ref.saveAllCompanies,
      companies = _ref.companies;
  var classes = Object(clientsPage["a" /* default */])();

  var _useState = Object(external_react_["useState"])(0),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      tabValue = _useState2[0],
      setTabValue = _useState2[1];

  Object(external_react_["useEffect"])(function () {
    return removeAllCompanies;
  }, [removeAllCompanies]);

  var findRelatedCompanies =
  /*#__PURE__*/
  function () {
    var _ref2 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee(_event, newValue) {
      var companies;
      return regenerator_default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              companies = [];
              setTabValue(newValue);
              _context.t0 = newValue;
              _context.next = _context.t0 === 2 ? 5 : _context.t0 === 1 ? 9 : _context.t0 === 0 ? 13 : 17;
              break;

            case 5:
              _context.next = 7;
              return Object(utils_clients["d" /* getInactiveCompanies */])();

            case 7:
              companies = _context.sent;
              return _context.abrupt("break", 18);

            case 9:
              _context.next = 11;
              return Object(utils_clients["c" /* getActiveCompanies */])();

            case 11:
              companies = _context.sent;
              return _context.abrupt("break", 18);

            case 13:
              _context.next = 15;
              return Object(utils_clients["e" /* getPendingCompanies */])();

            case 15:
              companies = _context.sent;
              return _context.abrupt("break", 18);

            case 17:
              companies = [];

            case 18:
              saveAllCompanies(companies);

            case 19:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function findRelatedCompanies(_x, _x2) {
      return _ref2.apply(this, arguments);
    };
  }();

  return external_react_default.a.createElement(Container_default.a, null, external_react_default.a.createElement(Typography_default.a, {
    variant: "h1",
    align: "center",
    className: classes.title
  }, arabicTranslation["a" /* default */].CLIENTS), external_react_default.a.createElement(components_ClientsFilters, null), external_react_default.a.createElement(Paper_default.a, null, external_react_default.a.createElement(Tabs_default.a, {
    value: tabValue,
    onChange: findRelatedCompanies,
    variant: "fullWidth",
    indicatorColor: "primary",
    textColor: "primary"
  }, external_react_default.a.createElement(Tab_default.a, {
    icon: external_react_default.a.createElement(Timer_default.a, null),
    label: arabicTranslation["a" /* default */].PENDING
  }), external_react_default.a.createElement(Tab_default.a, {
    icon: external_react_default.a.createElement(CheckboxMarkedCircleOutline_default.a, null),
    label: arabicTranslation["a" /* default */].ACTIVE
  }), external_react_default.a.createElement(Tab_default.a, {
    icon: external_react_default.a.createElement(Cancel_default.a, null),
    label: arabicTranslation["a" /* default */].INACTIVE
  })), external_react_default.a.createElement(components_ClientsTable, {
    clients: clients
  })));
};

clients_Clients.getInitialProps =
/*#__PURE__*/
function () {
  var _ref3 = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee2(ctx) {
    var _nextCookie, token, companies;

    return regenerator_default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _nextCookie = external_next_cookies_default()(ctx), token = _nextCookie.token;

            if (!token) {
              _context2.next = 7;
              break;
            }

            _context2.next = 4;
            return Object(utils_clients["e" /* getPendingCompanies */])();

          case 4:
            companies = _context2.sent;
            ctx.store.dispatch(Object(clientsActions["b" /* saveAllCompanies */])(companies));
            return _context2.abrupt("return", {
              companies: companies
            });

          case 7:
            return _context2.abrupt("return", Object(auth["e" /* redirectOnError */])(ctx));

          case 8:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function (_x3) {
    return _ref3.apply(this, arguments);
  };
}();

var clients_mapStateToProps = function mapStateToProps(state) {
  return {
    clients: Object(utils_clients["b" /* filterCompanies */])(state.clients, state.filters)
  };
};

var clients_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    removeAllCompanies: function removeAllCompanies() {
      return dispatch(Object(clientsActions["a" /* removeAllCompanies */])());
    },
    saveAllCompanies: function saveAllCompanies(companies) {
      return dispatch(Object(clientsActions["b" /* saveAllCompanies */])(companies));
    }
  };
};

/* harmony default export */ var pages_clients = __webpack_exports__["default"] = (Object(external_react_redux_["connect"])(clients_mapStateToProps, clients_mapDispatchToProps)(clients_Clients));

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "St2x":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/AccountCardDetails");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "TWtx":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableHead");

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _inherits; });
/* harmony import */ var _core_js_object_create__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SqZg");
/* harmony import */ var _core_js_object_create__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_create__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("VLay");


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _core_js_object_create__WEBPACK_IMPORTED_MODULE_0___default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object(_setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(subClass, superClass);
}

/***/ }),

/***/ "UVoM":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Typography");

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "Uynj":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Container");

/***/ }),

/***/ "VLay":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _setPrototypeOf; });
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0__);

function _setPrototypeOf(o, p) {
  _setPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

/***/ }),

/***/ "W+03":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemText");

/***/ }),

/***/ "Wh1t":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "XXOK":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("J3/a");

/***/ }),

/***/ "Xql+":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/map");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "aAV7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/reflect/construct");

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "b5DJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__("h74D");

// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__("dYMV");
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);

// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__("9Pu4");

// EXTERNAL MODULE: external "@material-ui/core/List"
var List_ = __webpack_require__("0LMq");
var List_default = /*#__PURE__*/__webpack_require__.n(List_);

// EXTERNAL MODULE: external "@material-ui/core/ListItem"
var ListItem_ = __webpack_require__("c25J");
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_);

// EXTERNAL MODULE: external "@material-ui/core/ListItemText"
var ListItemText_ = __webpack_require__("W+03");
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);

// EXTERNAL MODULE: external "@material-ui/core/Dialog"
var Dialog_ = __webpack_require__("fEgT");
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog_);

// EXTERNAL MODULE: external "@material-ui/core/DialogContent"
var DialogContent_ = __webpack_require__("iTUb");
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent_);

// EXTERNAL MODULE: external "@material-ui/core/CircularProgress"
var CircularProgress_ = __webpack_require__("1imS");
var CircularProgress_default = /*#__PURE__*/__webpack_require__.n(CircularProgress_);

// EXTERNAL MODULE: external "@material-ui/core/Grid"
var Grid_ = __webpack_require__("JQ2V");
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);

// EXTERNAL MODULE: external "@material-ui/core/TextField"
var TextField_ = __webpack_require__("IbbU");
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);

// EXTERNAL MODULE: external "@material-ui/core/InputAdornment"
var InputAdornment_ = __webpack_require__("lj8g");
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment_);

// EXTERNAL MODULE: external "@material-ui/core/Button"
var Button_ = __webpack_require__("Wh1t");
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);

// EXTERNAL MODULE: external "@material-ui/core/Typography"
var Typography_ = __webpack_require__("UVoM");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);

// EXTERNAL MODULE: ./translations/arabicTranslation.js
var arabicTranslation = __webpack_require__("4Ioi");

// EXTERNAL MODULE: ./components/DialogTitle.js
var DialogTitle = __webpack_require__("Aet0");

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// CONCATENATED MODULE: ./utils/wallet.js



var getWalletDetails =
/*#__PURE__*/
function () {
  var _ref = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(id) {
    var _ref2, data;

    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return external_axios_default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/order/").concat(id, "/wallet"));

          case 2:
            _ref2 = _context.sent;
            data = _ref2.data;
            return _context.abrupt("return", data);

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getWalletDetails(_x) {
    return _ref.apply(this, arguments);
  };
}();
var withdrawFromWallet =
/*#__PURE__*/
function () {
  var _ref3 = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee2(adminId, companyId, amount) {
    return regenerator_default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return external_axios_default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/order/").concat(companyId, "/withdrawWallet/").concat(adminId, "/").concat(amount));

          case 2:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function withdrawFromWallet(_x2, _x3, _x4) {
    return _ref3.apply(this, arguments);
  };
}();
// CONCATENATED MODULE: ./redux/actions/loadingActions.js
var loadingActions_startLoading = function startLoading() {
  return {
    type: 'LOADING'
  };
};
var loadingActions_endLoading = function endLoading() {
  return {
    type: 'NOT_LOADING'
  };
};
// CONCATENATED MODULE: ./components/WalletDetails.js























var useStyles = Object(styles_["makeStyles"])(function (theme) {
  return {
    textCentre: {
      textAlign: 'center'
    }
  };
});

var WalletDetails_WalletDetails = function WalletDetails(_ref) {
  var onClose = _ref.onClose,
      open = _ref.open,
      client = _ref.client,
      loading = _ref.loading,
      startLoading = _ref.startLoading,
      endLoading = _ref.endLoading,
      adminId = _ref.adminId;
  var classes = useStyles();

  var _useState = Object(external_react_["useState"])(null),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      wallet = _useState2[0],
      setWallet = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(''),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      withdraw = _useState4[0],
      setWithdraw = _useState4[1];

  var _useState5 = Object(external_react_["useState"])(''),
      _useState6 = Object(slicedToArray["a" /* default */])(_useState5, 2),
      message = _useState6[0],
      setMessage = _useState6[1];

  var _useState7 = Object(external_react_["useState"])(false),
      _useState8 = Object(slicedToArray["a" /* default */])(_useState7, 2),
      error = _useState8[0],
      setError = _useState8[1];

  Object(external_react_["useEffect"])(function () {
    var fetchData =
    /*#__PURE__*/
    function () {
      var _ref2 = Object(asyncToGenerator["a" /* default */])(
      /*#__PURE__*/
      regenerator_default.a.mark(function _callee() {
        var walletData;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return getWalletDetails(client.companyId);

              case 2:
                walletData = _context.sent;
                setWallet(walletData);

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function fetchData() {
        return _ref2.apply(this, arguments);
      };
    }();

    fetchData();
  }, [client.companyId]);

  var handleWithdraw =
  /*#__PURE__*/
  function () {
    var _ref3 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee2() {
      var walletData;
      return regenerator_default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              startLoading();
              _context2.next = 4;
              return withdrawFromWallet(adminId, client.companyId, withdraw);

            case 4:
              setMessage(arabicTranslation["a" /* default */].WITHDRAW_SUCCESS);
              setWithdraw('');
              _context2.next = 8;
              return getWalletDetails(client.companyId);

            case 8:
              walletData = _context2.sent;
              setWallet(walletData);
              endLoading();
              _context2.next = 18;
              break;

            case 13:
              _context2.prev = 13;
              _context2.t0 = _context2["catch"](0);
              endLoading();
              setMessage(arabicTranslation["a" /* default */].FAILED_WITHDRAW);
              setError(true);

            case 18:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 13]]);
    }));

    return function handleWithdraw() {
      return _ref3.apply(this, arguments);
    };
  }();

  return external_react_default.a.createElement(Dialog_default.a, {
    onClose: onClose,
    open: open,
    maxWidth: "xs",
    fullWidth: true
  }, external_react_default.a.createElement(DialogTitle["a" /* default */], {
    onClose: onClose
  }, client.name), external_react_default.a.createElement(DialogContent_default.a, {
    dividers: true,
    className: external_clsx_default()(Object(defineProperty["a" /* default */])({}, classes.textCentre, !wallet))
  }, !wallet && external_react_default.a.createElement(CircularProgress_default.a, null), wallet && external_react_default.a.createElement(List_default.a, null, external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].TOTAL_PROFIT, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.profit, " SAR")))), !client.isNonProfit && external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].COMISSION, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.commission, " SAR")))), external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].TRANSFERRED_PROFIT, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.transferredProfit, " SAR")))), external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, {
    style: {
      color: 'red'
    }
  }, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].CURRENT_BALANCE, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.currentBalance, " SAR")))), external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 6
  }, external_react_default.a.createElement(Button_default.a, {
    color: "primary",
    variant: "contained",
    disabled: !withdraw || withdraw <= 0 || loading,
    onClick: handleWithdraw
  }, arabicTranslation["a" /* default */].WITHDRAW)), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 6
  }, external_react_default.a.createElement(TextField_default.a, {
    value: withdraw,
    onChange: function onChange(e) {
      return setWithdraw(e.target.value);
    },
    type: "number",
    InputProps: {
      endAdornment: external_react_default.a.createElement(InputAdornment_default.a, {
        position: "end"
      }, "SAR")
    },
    error: withdraw < 0,
    helperText: withdraw < 0 && arabicTranslation["a" /* default */].LOWER_ZERO
  }))))), message && external_react_default.a.createElement(Typography_default.a, {
    align: "center",
    color: error ? 'error' : 'initial'
  }, message)));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    loading: state.loading,
    adminId: state.auth.adminId
  };
};

var WalletDetails_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    startLoading: function startLoading() {
      return dispatch(loadingActions_startLoading());
    },
    endLoading: function endLoading() {
      return dispatch(loadingActions_endLoading());
    }
  };
};

/* harmony default export */ var components_WalletDetails = __webpack_exports__["a"] = (Object(external_react_redux_["connect"])(mapStateToProps, WalletDetails_mapDispatchToProps)(WalletDetails_WalletDetails));

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "c25J":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItem");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault2 = __webpack_require__("KI45");

var _classCallCheck2 = _interopRequireDefault2(__webpack_require__("0iUn"));

var _createClass2 = _interopRequireDefault2(__webpack_require__("sLSF"));

var _possibleConstructorReturn2 = _interopRequireDefault2(__webpack_require__("MI3g"));

var _getPrototypeOf2 = _interopRequireDefault2(__webpack_require__("a7VT"));

var _inherits2 = _interopRequireDefault2(__webpack_require__("Tit0"));

var _interopRequireWildcard = __webpack_require__("5Uuq");

var _interopRequireDefault = __webpack_require__("KI45");

exports.__esModule = true;
exports["default"] = void 0;

var _map = _interopRequireDefault(__webpack_require__("LX0d"));

var _url = __webpack_require__("bzos");

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _propTypes = _interopRequireDefault(__webpack_require__("rf6O"));

var _router = _interopRequireDefault(__webpack_require__("nOHt"));

var _rewriteUrlForExport = __webpack_require__("+NUC");

var _utils = __webpack_require__("p8BD");
/* global __NEXT_DATA__ */


function isLocal(href) {
  var url = (0, _url.parse)(href, false, true);
  var origin = (0, _url.parse)((0, _utils.getLocationOrigin)(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (lastResult && href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? (0, _utils.formatWithValidation)(url) : url;
}

var observer;
var listeners = new _map["default"]();
var IntersectionObserver =  false ? undefined : null;

function getObserver() {
  // Return shared instance of IntersectionObserver if already created
  if (observer) {
    return observer;
  } // Only create shared IntersectionObserver if supported in browser


  if (!IntersectionObserver) {
    return undefined;
  }

  return observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!listeners.has(entry.target)) {
        return;
      }

      var cb = listeners.get(entry.target);

      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        observer.unobserve(entry.target);
        listeners["delete"](entry.target);
        cb();
      }
    });
  }, {
    rootMargin: '200px'
  });
}

var listenToIntersections = function listenToIntersections(el, cb) {
  var observer = getObserver();

  if (!observer) {
    return function () {};
  }

  observer.observe(el);
  listeners.set(el, cb);
  return function () {
    observer.unobserve(el);
    listeners["delete"](el);
  };
};

var Link =
/*#__PURE__*/
function (_react$Component) {
  (0, _inherits2["default"])(Link, _react$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2["default"])(this, Link);
    _this = (0, _possibleConstructorReturn2["default"])(this, (0, _getPrototypeOf2["default"])(Link).apply(this, arguments));

    _this.cleanUpListeners = function () {};

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: asHref ? formatUrl(asHref) : asHref
      };
    });

    _this.linkClicked = function (e) {
      // @ts-ignore target exists on currentTarget
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = (0, _url.resolve)(pathname, href);
      as = as ? (0, _url.resolve)(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      _router["default"][_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      })["catch"](function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2["default"])(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.cleanUpListeners = function () {};
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.cleanUpListeners();
    }
  }, {
    key: "handleRef",
    value: function handleRef(ref) {
      var _this2 = this;

      if (this.props.prefetch && IntersectionObserver && ref && ref.tagName) {
        this.cleanUpListeners = listenToIntersections(ref, function () {
          _this2.prefetch();
        });
      }
    } // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch || "undefined" === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = (0, _url.resolve)(pathname, parsedHref);

      _router["default"].prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = _react["default"].createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = _react.Children.only(children);

      var props = {
        ref: function ref(el) {
          return _this3.handleRef(el);
        },
        onMouseEnter: function onMouseEnter(e) {
          if (child.props && typeof child.props.onMouseEnter === 'function') {
            child.props.onMouseEnter(e);
          }

          _this3.prefetch();
        },
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this3.linkClicked(e);
          }
        } // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
        // defined, we specify the current 'href', so that repetition is not needed by the user

      };

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (false) {}

      return _react["default"].cloneElement(child, props);
    }
  }]);
  return Link;
}(_react.Component);

Link.propTypes = void 0;
Link.defaultProps = {
  prefetch: true
};

if (false) { var exact, warn; }

var _default = Link;
exports["default"] = _default;

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "dYMV":
/***/ (function(module, exports) {

module.exports = require("clsx");

/***/ }),

/***/ "doui":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js

function _arrayWithHoles(arr) {
  if (is_array_default()(arr)) return arr;
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js
var get_iterator = __webpack_require__("XXOK");
var get_iterator_default = /*#__PURE__*/__webpack_require__.n(get_iterator);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = get_iterator_default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _slicedToArray; });



function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "eaXY":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/FileDocument");

/***/ }),

/***/ "eoIS":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Instagram");

/***/ }),

/***/ "fEgT":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Dialog");

/***/ }),

/***/ "fdDk":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Wallet");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "gXGL":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Close");

/***/ }),

/***/ "h74D":
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "htGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$assign = __webpack_require__("UXZV");

function _extends() {
  module.exports = _extends = _Object$assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "iDDF":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableRow");

/***/ }),

/***/ "iTUb":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogContent");

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "lj8g":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/InputAdornment");

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "mJK4":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/router-context");

/***/ }),

/***/ "mgRA":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _construct; });
/* harmony import */ var _core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("pbKT");
/* harmony import */ var _core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("VLay");



function isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !_core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0___default.a) return false;
  if (_core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0___default.a.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(_core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0___default()(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _construct(Parent, args, Class) {
  if (isNativeReflectConstruct()) {
    _construct = _core_js_reflect_construct__WEBPACK_IMPORTED_MODULE_0___default.a;
  } else {
    _construct = function _construct(Parent, args, Class) {
      var a = [null];
      a.push.apply(a, args);
      var Constructor = Function.bind.apply(Parent, a);
      var instance = new Constructor();
      if (Class) Object(_setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(instance, Class.prototype);
      return instance;
    };
  }

  return _construct.apply(null, arguments);
}

/***/ }),

/***/ "mxtS":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Web");

/***/ }),

/***/ "nFSa":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/City");

/***/ }),

/***/ "nOHt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault2 = __webpack_require__("KI45");

var _construct2 = _interopRequireDefault2(__webpack_require__("mgRA"));

var _interopRequireDefault = __webpack_require__("KI45");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.useRequest = useRequest;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports["default"] = void 0;

var _extends2 = _interopRequireDefault(__webpack_require__("htGi"));

var _defineProperty = _interopRequireDefault(__webpack_require__("hfKm"));

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireDefault(__webpack_require__("qxCs"));

exports.Router = _router2["default"];

var _routerContext = __webpack_require__("mJK4");

var _requestContext = __webpack_require__("qCSu");

var _withRouter = _interopRequireDefault(__webpack_require__("0Bsm"));

exports.withRouter = _withRouter["default"];
/* global window */

var singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],
  ready: function ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }
}; // Create public properties and methods of the router in the singletonRouter

var urlPropertyFields = ['pathname', 'route', 'query', 'asPath'];
var propertyFields = ['components'];
var routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
var coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

(0, _defineProperty["default"])(singletonRouter, 'events', {
  get: function get() {
    return _router2["default"].events;
  }
});
propertyFields.concat(urlPropertyFields).forEach(function (field) {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  (0, _defineProperty["default"])(singletonRouter, field, {
    get: function get() {
      var router = getRouter();
      return router[field];
    }
  });
});
coreMethodFields.forEach(function (field) {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = function () {
    var router = getRouter();
    return router[field].apply(router, arguments);
  };
});
routerEvents.forEach(function (event) {
  singletonRouter.ready(function () {
    _router2["default"].events.on(event, function () {
      var eventField = "on" + event.charAt(0).toUpperCase() + event.substring(1);
      var _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField].apply(_singletonRouter, arguments);
        } catch (err) {
          // tslint:disable-next-line:no-console
          console.error("Error when running the Router event: " + eventField); // tslint:disable-next-line:no-console

          console.error(err.message + "\n" + err.stack);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    var message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports["default"] = _default;

function useRouter() {
  return _react["default"].useContext(_routerContext.RouterContext);
}

function useRequest() {
  return _react["default"].useContext(_requestContext.RequestContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


var createRouter = function createRouter() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  singletonRouter.router = (0, _construct2["default"])(_router2["default"], args);
  singletonRouter.readyCallbacks.forEach(function (cb) {
    return cb();
  });
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  var _router = router;
  var instance = {};

  for (var _i = 0, _urlPropertyFields = urlPropertyFields; _i < _urlPropertyFields.length; _i++) {
    var property = _urlPropertyFields[_i];

    if (typeof _router[property] === 'object') {
      instance[property] = (0, _extends2["default"])({}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2["default"].events;
  propertyFields.forEach(function (field) {
    // Here we need to use Object.defineProperty because, we need to return
    // the property assigned to the actual router
    // The value might get changed as we change routes and this is the
    // proper way to access it
    (0, _defineProperty["default"])(instance, field, {
      get: function get() {
        return _router[field];
      }
    });
  });
  coreMethodFields.forEach(function (field) {
    instance[field] = function () {
      return _router[field].apply(_router, arguments);
    };
  });
  return instance;
}

/***/ }),

/***/ "ncp3":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/CellphoneAndroid");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p0XB":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("R2Q7");

/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "pbKT":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aAV7");

/***/ }),

/***/ "qCSu":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/request-context");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qt1I":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Paper");

/***/ }),

/***/ "qxCs":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/router/router");

/***/ }),

/***/ "r6Lb":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Checkbox");

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "vF8F":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Tooltip");

/***/ }),

/***/ "vW2u":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/MapMarker");

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vmXh":
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "y6vh":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/date/now");

/***/ }),

/***/ "zTfa":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Timer");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });