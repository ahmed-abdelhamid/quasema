module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "0Jp5":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogTitle");

/***/ }),

/***/ "0LMq":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/List");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1imS":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CircularProgress");

/***/ }),

/***/ "2I19":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return saveAllCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return saveChangeCompanyState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return removeAllCompanies; });
var saveAllCompanies = function saveAllCompanies(companies) {
  return {
    type: 'SAVE_ALL',
    companies: companies
  };
};
var saveChangeCompanyState = function saveChangeCompanyState(company) {
  return {
    type: 'CHANGE_STATE',
    company: company
  };
};
var removeAllCompanies = function removeAllCompanies() {
  return {
    type: 'REMOVE_ALL'
  };
};

/***/ }),

/***/ "30mr":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableBody");

/***/ }),

/***/ "3i/4":
/***/ (function(module, exports) {

module.exports = require("next-cookies");

/***/ }),

/***/ "4Ioi":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  TITLE: 'قسيمه',
  HEADER_TITLE: 'قسيمه',
  HOME: 'الرئيسية',
  CLIENTS: 'مقدمى العروض',
  USERS: 'مستخدمى التطبيق',
  OFFERS: 'العروض',
  REPORTS: 'البلاغات',
  CHANGE_PASSWORD: 'تغيير كلمة المرور',
  LOGOUT: 'تسجيل الخروج',
  REQUIRED_FILED: 'حقل إلزامى',
  LOGIN: 'تسجيل الدخول',
  EMAIL_OR_PHONE: 'البريد الألكترونى أو رقم الجوال',
  PASSWORD: 'كلمة المرور',
  CREDENTIALS_ERROR: 'خطأ فى اسم المستخدم أو كلمة المرور',
  LOADING: 'جارى التحميل',
  PENDING: 'فى انتظار التفعيل',
  ACTIVE: 'مقدمى العروض النشيطين',
  INACTIVE: 'مقدمى العروض الغير نشيطين',
  PROFIT: 'شركات ربحية',
  NON_PROFIT: 'جمعيات خيرية',
  NAME: 'الاسم',
  MOI_NUMBER: 'رقم السجل التجارى',
  CITY: 'المدينة',
  MOBILE_NUMBER: 'رقم الجوال',
  NOTHING: 'لا يوجد',
  SHOW_DETAILS: 'عرض التفاصيل',
  ACTIVATE: 'تفعيل',
  DEACTIVATE: 'تعطيل',
  WALLET: 'المحفظة',
  EMAIL: 'البريد الالكترونى',
  WEB_URL: 'الموقع الاكترونى',
  TWITTER: 'حساب تويتر',
  INSTGRAM: 'حساب الانستجرام',
  DESCRIPTION: 'نبذة عن مقدم العرض',
  LOCATION: 'الموقع على الخريطة',
  NO_WALLET_DETAILS: 'لا يوجد رصيد بالمحظة',
  CURRENT_BALANCE: 'الرصيد الحالى',
  TOTAL_PROFIT: 'مجموع الارباح',
  COMISSION: 'عمولة قسيمة',
  TRANSFERRED_PROFIT: 'الارباح المحولة مسبقا',
  WITHDRAW: 'اجراء تحويل',
  LOWER_ZERO: 'يجب ان يكون المبلغ المحول اكثر من صفر',
  WITHDRAW_SUCCESS: 'تمت عملية التحويل بنجاح',
  FAILED_WITHDRAW: 'فشل فى عملية التحويل. يرجى إعادة المحاولة',
  PURCHASES: 'المشتريات',
  NO_ORDERS: 'لا يوجد مشتريات لهذا المستخدم',
  QUASEMA_NAME: 'اسم القسيمة',
  QUASEMA_PROVIDER_NAME: 'اسم مقدم القسيمة',
  QUASEMA_TYPE: 'نوع القسيمة',
  QUASEMA_COST: 'مبلغ القسيمة',
  QUASEMA_AMOUNT: 'عدد القسائم التى تم شرائها',
  QUASEMA_ORDER_NO: 'رقم الطلب',
  QUASEMA_ORDER_DATE: 'تاريخ الطلب',
  labelDisplayedRows: function labelDisplayedRows(_ref) {
    var from = _ref.from,
        to = _ref.to,
        count = _ref.count;
    return "".concat(from, " - ").concat(to, " \u0645\u0646 \u0627\u062C\u0645\u0627\u0644\u0649 ").concat(count);
  },
  ROWS_PER_PAGE: 'عدد الوحدات بالصفحة',
  USERNAME: 'اسم المستخدم',
  OFFER_NAME: 'اسم العرض',
  OFFER_PROVIDER_NAME: 'اسم مقدم العرض',
  OFFER_PRICE: 'السعر',
  OFFER_RATE: 'التقييم',
  SHOW_IMAGES: 'عرض الصور',
  FORGET_PASSWORD: 'نسيت كلمة المرور',
  RESET_PASSWORD: 'استعادة كلمة المرور',
  WRONG_EMAIL: 'البريد الالكترونى غير صحيح',
  OLD_PASSWORD: 'كلمة المرور الحالية',
  NEW_PASSWORD: 'كلمة المرور الجديدة',
  WRONG_OLD_PASSWORD: 'كلمة المرور الحالية غير صحيحة',
  NO_OFFERS: 'لا يوجد عروض',
  CATEGORY: 'القسم',
  ADDRESS: 'العنوان',
  OFFER_TYPE: 'نوع العرض',
  AMOUNT: 'العدد',
  EXPIRY: 'صلاحية العرض',
  ILLUSTRATION: 'شرح تفاصيل العرض',
  WHY: 'مميزات العرض',
  IMAGES_OFFERS: 'الصور الخاصة بالعرض',
  BEST_OFFERS: 'أقوى العروض',
  ALL: 'الكل',
  HOUSING: 'شاليهات ومنتجعات',
  COFFEESHOPS: 'مطاعم ومقاهى',
  CLINICS: 'مراكز وعيادات',
  TRAVEL: 'سياحة وسفر',
  BEAUTY_CENTERS: 'مراكز تجميل',
  SHOPPING: 'تسوق',
  FAMILIES: 'أسر منتجة',
  COURSES: 'دورات',
  OTHERS: 'أخري',
  BEST_SALES: 'الأكثر مبيعا',
  BEST_RATES: 'الأكثر تقييما',
  LESS_THAN_THIRTY: 'أقل من 30 ريال',
  CHARITY: 'خيرى',
  CONDITIONS: 'الشروط'
});

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("NhoZ");


/***/ }),

/***/ "50L+":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Cancel");

/***/ }),

/***/ "7hht":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Email");

/***/ }),

/***/ "9Pu4":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "Aet0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("9Pu4");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0Jp5");
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("EmCc");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("gXGL");
/* harmony import */ var mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4__);





var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__["makeStyles"])(function (theme) {
  return {
    title: {
      textAlign: 'center'
    },
    closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500]
    }
  };
});

var DialogTitle = function DialogTitle(_ref) {
  var children = _ref.children,
      onClose = _ref.onClose;
  var classes = useStyles();
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_2___default.a, {
    className: classes.title
  }, children, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3___default.a, {
    className: classes.closeButton,
    onClick: onClose
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Close__WEBPACK_IMPORTED_MODULE_4___default.a, null)));
};

/* harmony default export */ __webpack_exports__["a"] = (DialogTitle);

/***/ }),

/***/ "Ai9N":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableCell");

/***/ }),

/***/ "BUv7":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Pencil");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "BjFw":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Table");

/***/ }),

/***/ "Cg2A":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("y6vh");

/***/ }),

/***/ "Dl9a":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Twitter");

/***/ }),

/***/ "EmCc":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/IconButton");

/***/ }),

/***/ "GLYF":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemIcon");

/***/ }),

/***/ "H20q":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/CheckboxMarkedCircleOutline");

/***/ }),

/***/ "H5EN":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return getPendingCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getActiveCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getInactiveCompanies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return changeCompanyState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return filterCompanies; });
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ln6h");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("O40h");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);



var getPendingCompanies =
/*#__PURE__*/
function () {
  var _ref = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getallcompany/", true, "/", false));

          case 2:
            response = _context.sent;
            return _context.abrupt("return", response.data);

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getPendingCompanies() {
    return _ref.apply(this, arguments);
  };
}();
var getActiveCompanies =
/*#__PURE__*/
function () {
  var _ref2 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getallcompany/", false, "/", false));

          case 2:
            response = _context2.sent;
            return _context2.abrupt("return", response.data);

          case 4:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function getActiveCompanies() {
    return _ref2.apply(this, arguments);
  };
}();
var getInactiveCompanies =
/*#__PURE__*/
function () {
  var _ref3 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getallcompany/", false, "/", true));

          case 2:
            response = _context3.sent;
            return _context3.abrupt("return", response.data);

          case 4:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function getInactiveCompanies() {
    return _ref3.apply(this, arguments);
  };
}();
var changeCompanyState =
/*#__PURE__*/
function () {
  var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4(id, activity, pending) {
    var response;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/changecompanystatus/").concat(id, "/").concat(activity, "/").concat(pending));

          case 2:
            response = _context4.sent;
            return _context4.abrupt("return", response.data);

          case 4:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function changeCompanyState(_x, _x2, _x3) {
    return _ref4.apply(this, arguments);
  };
}();
var filterCompanies = function filterCompanies(companies, filters) {
  switch (filters.filterClientsBy) {
    case 'profit':
      return companies.filter(function (_ref5) {
        var company = _ref5.company;
        return !company.isNonProfit;
      });

    case 'nonProfit':
      return companies.filter(function (_ref6) {
        var company = _ref6.company;
        return company.isNonProfit;
      });

    default:
      return companies;
  }
};

/***/ }),

/***/ "IbbU":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TextField");

/***/ }),

/***/ "J3/a":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "JQ2V":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "LK70":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("MCme");
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("EmCc");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0LMq");
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("c25J");
/* harmony import */ var _material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("GLYF");
/* harmony import */ var _material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("W+03");
/* harmony import */ var _material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("fEgT");
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("iTUb");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("JQ2V");
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("7hht");
/* harmony import */ var mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("ncp3");
/* harmony import */ var mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("eaXY");
/* harmony import */ var mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("nFSa");
/* harmony import */ var mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("mxtS");
/* harmony import */ var mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("Dl9a");
/* harmony import */ var mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("eoIS");
/* harmony import */ var mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("BUv7");
/* harmony import */ var mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("vW2u");
/* harmony import */ var mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__("4Ioi");
/* harmony import */ var _DialogTitle__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__("Aet0");






















var ShowDetailsDialog = function ShowDetailsDialog(_ref) {
  var onClose = _ref.onClose,
      open = _ref.open,
      client = _ref.client;
  var LIST_ITEMS = [{
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].EMAIL,
    value: client.email,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Email__WEBPACK_IMPORTED_MODULE_10___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].MOBILE_NUMBER,
    value: client.mobile,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_CellphoneAndroid__WEBPACK_IMPORTED_MODULE_11___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].MOI_NUMBER,
    value: client.moi_Id,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_FileDocument__WEBPACK_IMPORTED_MODULE_12___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].CITY,
    value: client.city,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_City__WEBPACK_IMPORTED_MODULE_13___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].WEB_URL,
    value: client.webUrl,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Web__WEBPACK_IMPORTED_MODULE_14___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].TWITTER,
    value: client.twitter,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Twitter__WEBPACK_IMPORTED_MODULE_15___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].INSTGRAM,
    value: client.instgram,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Instagram__WEBPACK_IMPORTED_MODULE_16___default.a, null)
  }, {
    name: _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].DESCRIPTION,
    value: client.description,
    icon: react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_Pencil__WEBPACK_IMPORTED_MODULE_17___default.a, null)
  }];

  var renderLocationIcon = function renderLocationIcon() {
    if (!client.lat && !client.lag) {
      return _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].NOTHING;
    }

    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_1___default.a, {
      href: "https://www.google.com/maps/search/?api=1&query=".concat(client.lat, ",").concat(client.lag),
      target: "_blank"
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_2___default.a, {
      color: "secondary",
      style: {
        padding: 0
      }
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18___default.a, null)));
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_7___default.a, {
    onClose: onClose,
    open: open,
    fullWidth: true
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_DialogTitle__WEBPACK_IMPORTED_MODULE_20__[/* default */ "a"], {
    onClose: onClose
  }, client.name), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_8___default.a, {
    dividers: true
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_3___default.a, null, LIST_ITEMS.map(function (_ref2) {
    var name = _ref2.name,
        value = _ref2.value,
        icon = _ref2.icon;
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4___default.a, {
      key: name
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default.a, null, icon), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
      container: true,
      spacing: 2
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
      item: true,
      sm: 5
    }, name, ":"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
      item: true,
      sm: 7
    }, value))));
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_4___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdi_material_ui_MapMarker__WEBPACK_IMPORTED_MODULE_18___default.a, null)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_6___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
    container: true,
    spacing: 2
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
    item: true,
    sm: 5
  }, _translations_arabicTranslation__WEBPACK_IMPORTED_MODULE_19__[/* default */ "a"].LOCATION, ":"), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9___default.a, {
    item: true,
    sm: 7
  }, renderLocationIcon())))))));
};

/* harmony default export */ __webpack_exports__["a"] = (ShowDetailsDialog);

/***/ }),

/***/ "MCme":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Link");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "NCjo":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/SackPercent");

/***/ }),

/***/ "NhoZ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__("h74D");

// EXTERNAL MODULE: external "next-cookies"
var external_next_cookies_ = __webpack_require__("3i/4");
var external_next_cookies_default = /*#__PURE__*/__webpack_require__.n(external_next_cookies_);

// EXTERNAL MODULE: external "@material-ui/core/Paper"
var Paper_ = __webpack_require__("qt1I");
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);

// EXTERNAL MODULE: external "@material-ui/core/Container"
var Container_ = __webpack_require__("Uynj");
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);

// EXTERNAL MODULE: external "@material-ui/core/Typography"
var Typography_ = __webpack_require__("UVoM");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);

// EXTERNAL MODULE: ./styles/clientsPage.js
var clientsPage = __webpack_require__("S++P");

// EXTERNAL MODULE: ./translations/arabicTranslation.js
var arabicTranslation = __webpack_require__("4Ioi");

// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__("SMlj");

// CONCATENATED MODULE: ./redux/actions/usersActions.js
var saveAllUsers = function saveAllUsers(users) {
  return {
    type: 'SAVE_ALL_USERS',
    users: users
  };
};
var usersActions_removeAllUsers = function removeAllUsers() {
  return {
    type: 'REMOVE_ALL_USERS'
  };
};
// EXTERNAL MODULE: external "@material-ui/core/Table"
var Table_ = __webpack_require__("BjFw");
var Table_default = /*#__PURE__*/__webpack_require__.n(Table_);

// EXTERNAL MODULE: external "@material-ui/core/TableBody"
var TableBody_ = __webpack_require__("30mr");
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody_);

// EXTERNAL MODULE: external "@material-ui/core/TableCell"
var TableCell_ = __webpack_require__("Ai9N");
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell_);

// EXTERNAL MODULE: external "@material-ui/core/TableHead"
var TableHead_ = __webpack_require__("TWtx");
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead_);

// EXTERNAL MODULE: external "@material-ui/core/TableRow"
var TableRow_ = __webpack_require__("iDDF");
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: external "@material-ui/core/Button"
var Button_ = __webpack_require__("Wh1t");
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);

// EXTERNAL MODULE: external "@material-ui/core/IconButton"
var IconButton_ = __webpack_require__("EmCc");

// EXTERNAL MODULE: external "@material-ui/core/Tooltip"
var Tooltip_ = __webpack_require__("vF8F");

// EXTERNAL MODULE: external "mdi-material-ui/AccountCardDetails"
var AccountCardDetails_ = __webpack_require__("St2x");

// EXTERNAL MODULE: external "mdi-material-ui/CheckboxMarkedCircleOutline"
var CheckboxMarkedCircleOutline_ = __webpack_require__("H20q");

// EXTERNAL MODULE: external "mdi-material-ui/Cancel"
var Cancel_ = __webpack_require__("50L+");

// EXTERNAL MODULE: external "mdi-material-ui/SackPercent"
var SackPercent_ = __webpack_require__("NCjo");

// EXTERNAL MODULE: external "mdi-material-ui/Wallet"
var Wallet_ = __webpack_require__("fdDk");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__("dYMV");
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);

// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__("9Pu4");

// EXTERNAL MODULE: external "@material-ui/core/Dialog"
var Dialog_ = __webpack_require__("fEgT");
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog_);

// EXTERNAL MODULE: external "@material-ui/core/DialogContent"
var DialogContent_ = __webpack_require__("iTUb");
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent_);

// EXTERNAL MODULE: external "@material-ui/core/CircularProgress"
var CircularProgress_ = __webpack_require__("1imS");
var CircularProgress_default = /*#__PURE__*/__webpack_require__.n(CircularProgress_);

// EXTERNAL MODULE: ./components/DialogTitle.js
var DialogTitle = __webpack_require__("Aet0");

// EXTERNAL MODULE: external "@material-ui/core/TablePagination"
var TablePagination_ = __webpack_require__("bzUq");
var TablePagination_default = /*#__PURE__*/__webpack_require__.n(TablePagination_);

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// CONCATENATED MODULE: ./utils/orders.js



var getOrdersForUser =
/*#__PURE__*/
function () {
  var _ref = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(userId) {
    var pageSize,
        pageNumber,
        _ref2,
        data,
        _args = arguments;

    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            pageSize = _args.length > 1 && _args[1] !== undefined ? _args[1] : 5;
            pageNumber = _args.length > 2 && _args[2] !== undefined ? _args[2] : 0;
            _context.next = 4;
            return external_axios_default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/order/getUserOrders/").concat(userId, "?size=").concat(pageSize, "&page=").concat(pageNumber));

          case 4:
            _ref2 = _context.sent;
            data = _ref2.data;
            return _context.abrupt("return", data);

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getOrdersForUser(_x) {
    return _ref.apply(this, arguments);
  };
}();
// CONCATENATED MODULE: ./components/OrdersTable.js













var OrdersTable_OrdersTable = function OrdersTable(_ref) {
  var orders = _ref.orders,
      userId = _ref.userId;

  var _useState = Object(external_react_["useState"])(orders.content),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      currentOrders = _useState2[0],
      setCurrentOrders = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(0),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      page = _useState4[0],
      setPage = _useState4[1];

  var _useState5 = Object(external_react_["useState"])(orders.size),
      _useState6 = Object(slicedToArray["a" /* default */])(_useState5, 2),
      rowsPerPage = _useState6[0],
      setRowsPerPage = _useState6[1];

  var handleChangePage =
  /*#__PURE__*/
  function () {
    var _ref2 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee(_event, newPage) {
      var orders;
      return regenerator_default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return getOrdersForUser(userId, rowsPerPage, newPage);

            case 2:
              orders = _context.sent;
              setCurrentOrders(orders.content);
              setPage(newPage);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function handleChangePage(_x, _x2) {
      return _ref2.apply(this, arguments);
    };
  }();

  var handleChangeRowsPerPage =
  /*#__PURE__*/
  function () {
    var _ref3 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee2(event) {
      var orders;
      return regenerator_default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return getOrdersForUser(userId, +event.target.value);

            case 2:
              orders = _context2.sent;
              setCurrentOrders(orders.content);
              setRowsPerPage(+event.target.value);
              setPage(0);

            case 6:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function handleChangeRowsPerPage(_x3) {
      return _ref3.apply(this, arguments);
    };
  }();

  return external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement(Table_default.a, {
    dir: "rtl"
  }, external_react_default.a.createElement(TableHead_default.a, null, external_react_default.a.createElement(TableRow_default.a, null, external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_NAME), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_PROVIDER_NAME), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_TYPE), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_COST), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_AMOUNT), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_ORDER_NO), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].QUASEMA_ORDER_DATE))), external_react_default.a.createElement(TableBody_default.a, null, currentOrders.map(function (order) {
    return external_react_default.a.createElement(TableRow_default.a, {
      key: order.orderId
    }, external_react_default.a.createElement(TableCell_default.a, null, order.product.title), external_react_default.a.createElement(TableCell_default.a, null, order.product.company.user.name), external_react_default.a.createElement(TableCell_default.a, null, order.product.productType.name), external_react_default.a.createElement(TableCell_default.a, null, order.product.newPrice), external_react_default.a.createElement(TableCell_default.a, null, order.quntity), external_react_default.a.createElement(TableCell_default.a, null, order.orderId), external_react_default.a.createElement(TableCell_default.a, null, order.creationDate));
  }))), external_react_default.a.createElement(TablePagination_default.a, {
    rowsPerPageOptions: [5, 10, 20],
    component: "div",
    count: orders.totalElements,
    rowsPerPage: rowsPerPage,
    page: page,
    onChangePage: handleChangePage,
    onChangeRowsPerPage: handleChangeRowsPerPage,
    labelDisplayedRows: function labelDisplayedRows(_ref4) {
      var from = _ref4.from,
          to = _ref4.to,
          count = _ref4.count;
      return arabicTranslation["a" /* default */].labelDisplayedRows({
        from: from,
        to: to,
        count: count
      });
    },
    labelRowsPerPage: arabicTranslation["a" /* default */].ROWS_PER_PAGE
  }));
};

/* harmony default export */ var components_OrdersTable = (OrdersTable_OrdersTable);
// CONCATENATED MODULE: ./components/Orders.js















var useStyles = Object(styles_["makeStyles"])(function (theme) {
  return {
    textCentre: {
      textAlign: 'center'
    }
  };
});

var Orders_WalletDetails = function WalletDetails(_ref) {
  var user = _ref.user,
      onClose = _ref.onClose,
      open = _ref.open;
  var classes = useStyles();

  var _useState = Object(external_react_["useState"])(null),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      orders = _useState2[0],
      setOrders = _useState2[1];

  Object(external_react_["useEffect"])(function () {
    var fetchData =
    /*#__PURE__*/
    function () {
      var _ref2 = Object(asyncToGenerator["a" /* default */])(
      /*#__PURE__*/
      regenerator_default.a.mark(function _callee() {
        var response;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return getOrdersForUser(user.userId);

              case 2:
                response = _context.sent;
                setOrders(response);

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function fetchData() {
        return _ref2.apply(this, arguments);
      };
    }();

    fetchData();
  }, [user.userId]);
  return external_react_default.a.createElement(Dialog_default.a, {
    onClose: onClose,
    open: open,
    fullWidth: true,
    maxWidth: "lg"
  }, external_react_default.a.createElement(DialogTitle["a" /* default */], {
    onClose: onClose
  }, user.name), external_react_default.a.createElement(DialogContent_default.a, {
    dividers: true,
    className: external_clsx_default()(Object(defineProperty["a" /* default */])({}, classes.textCentre, !orders))
  }, !orders && external_react_default.a.createElement(CircularProgress_default.a, null), orders && orders.content.length === 0 && external_react_default.a.createElement(Typography_default.a, {
    align: "center",
    variant: "h6"
  }, arabicTranslation["a" /* default */].NO_ORDERS), orders && orders.content.length > 0 && external_react_default.a.createElement(components_OrdersTable, {
    orders: orders,
    userId: user.userId
  })));
};

/* harmony default export */ var Orders = (Orders_WalletDetails);
// EXTERNAL MODULE: ./components/ShowClientDetails.js
var ShowClientDetails = __webpack_require__("LK70");

// EXTERNAL MODULE: ./components/WalletDetails.js + 2 modules
var components_WalletDetails = __webpack_require__("b5DJ");

// EXTERNAL MODULE: ./utils/clients.js
var clients = __webpack_require__("H5EN");

// EXTERNAL MODULE: ./redux/actions/clientsActions.js
var clientsActions = __webpack_require__("2I19");

// CONCATENATED MODULE: ./components/UsersTableButtons.js


















var UsersTableButtons_UsersTableButtons = function UsersTableButtons(_ref) {
  var user = _ref.user;

  var _useState = Object(external_react_["useState"])(false),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      openOrders = _useState2[0],
      setOpenOrders = _useState2[1];

  return external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement(Button_default.a, {
    color: "primary",
    onClick: function onClick() {
      return setOpenOrders(true);
    }
  }, arabicTranslation["a" /* default */].PURCHASES), openOrders && external_react_default.a.createElement(Orders, {
    open: openOrders,
    onClose: function onClose() {
      return setOpenOrders(false);
    },
    user: user
  }));
};

var UsersTableButtons_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    saveChangeCompanyState: function saveChangeCompanyState(company) {
      return dispatch(Object(clientsActions["c" /* saveChangeCompanyState */])(company));
    }
  };
};

/* harmony default export */ var components_UsersTableButtons = (Object(external_react_redux_["connect"])(null, UsersTableButtons_mapDispatchToProps)(UsersTableButtons_UsersTableButtons));
// CONCATENATED MODULE: ./components/UsersTable.js











var UsersTable_UsersTable = function UsersTable(_ref) {
  var users = _ref.users;
  var classes = Object(clientsPage["a" /* default */])();

  if (users.length === 0) {
    return external_react_default.a.createElement(Typography_default.a, {
      className: classes.info,
      align: "center",
      gutterBottom: true
    }, arabicTranslation["a" /* default */].NOTHING);
  }

  return external_react_default.a.createElement(Table_default.a, {
    dir: "rtl"
  }, external_react_default.a.createElement(TableHead_default.a, null, external_react_default.a.createElement(TableRow_default.a, null, external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].NAME), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].EMAIL), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].CITY), external_react_default.a.createElement(TableCell_default.a, null, arabicTranslation["a" /* default */].MOBILE_NUMBER), external_react_default.a.createElement(TableCell_default.a, null))), external_react_default.a.createElement(TableBody_default.a, null, users.map(function (user) {
    return external_react_default.a.createElement(TableRow_default.a, {
      key: user.userId
    }, external_react_default.a.createElement(TableCell_default.a, null, user.name), external_react_default.a.createElement(TableCell_default.a, null, user.email), external_react_default.a.createElement(TableCell_default.a, null, user.city), external_react_default.a.createElement(TableCell_default.a, null, user.mobile), external_react_default.a.createElement(TableCell_default.a, {
      align: "center"
    }, external_react_default.a.createElement(components_UsersTableButtons, {
      user: user
    })));
  })));
};

/* harmony default export */ var components_UsersTable = (UsersTable_UsersTable);
// CONCATENATED MODULE: ./utils/users.js



var getAllUsers =
/*#__PURE__*/
function () {
  var _ref = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee() {
    var _ref2, data;

    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return external_axios_default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/user/getonlyuser"));

          case 2:
            _ref2 = _context.sent;
            data = _ref2.data;
            return _context.abrupt("return", data);

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getAllUsers() {
    return _ref.apply(this, arguments);
  };
}();
// CONCATENATED MODULE: ./pages/users.js




 // Material UI Imports











var users_Users = function Users(_ref) {
  var users = _ref.users,
      removeAllUsers = _ref.removeAllUsers;
  var classes = Object(clientsPage["a" /* default */])();
  Object(external_react_["useEffect"])(function () {
    return removeAllUsers;
  }, [removeAllUsers]);
  return external_react_default.a.createElement(Container_default.a, null, external_react_default.a.createElement(Typography_default.a, {
    variant: "h1",
    align: "center",
    className: classes.title
  }, arabicTranslation["a" /* default */].USERS), external_react_default.a.createElement(Paper_default.a, null, external_react_default.a.createElement(components_UsersTable, {
    users: users
  })));
};

users_Users.getInitialProps =
/*#__PURE__*/
function () {
  var _ref2 = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(ctx) {
    var _nextCookie, token, users;

    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _nextCookie = external_next_cookies_default()(ctx), token = _nextCookie.token;

            if (!token) {
              _context.next = 7;
              break;
            }

            _context.next = 4;
            return getAllUsers();

          case 4:
            users = _context.sent;
            ctx.store.dispatch(saveAllUsers(users));
            return _context.abrupt("return", {});

          case 7:
            return _context.abrupt("return", Object(auth["e" /* redirectOnError */])(ctx));

          case 8:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref2.apply(this, arguments);
  };
}();

var mapStateToProps = function mapStateToProps(_ref3) {
  var users = _ref3.users;
  return {
    users: users
  };
};

var users_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    removeAllUsers: function removeAllUsers() {
      return dispatch(usersActions_removeAllUsers());
    }
  };
};

/* harmony default export */ var pages_users = __webpack_exports__["default"] = (Object(external_react_redux_["connect"])(mapStateToProps, users_mapDispatchToProps)(users_Users));

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "R2Q7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "S++P":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9Pu4");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["a"] = (Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])({
  root: {
    flexGrow: 1,
    maxWidth: 500
  },
  title: {
    fontSize: 50,
    marginBottom: 25
  },
  info: {
    fontSize: 25,
    paddingTop: 10
  },
  paper: {
    minHeight: '30vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  }
}));

/***/ }),

/***/ "SMlj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return redirectOnError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return withAuthSync; });
/* unused harmony export auth */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return changePassword; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return forgetPassword; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("zrwo");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("AT/M");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("vYYK");
/* harmony import */ var _babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("Cg2A");
/* harmony import */ var _babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("ln6h");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("O40h");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("3i/4");
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_cookies__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("vmXh");
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_15__);















 // Redirect on Error

var redirectOnError = function redirectOnError(ctx) {
   false ? undefined : ctx.res.writeHead(302, {
    location: '/login'
  }).end();
}; // Login Admin

var login =
/*#__PURE__*/
function () {
  var _ref2 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee(_ref) {
    var token;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            token = _ref.token;
            js_cookie__WEBPACK_IMPORTED_MODULE_15___default.a.set('token', token, {
              expires: 1
            });
            next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/clients');

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function login(_x) {
    return _ref2.apply(this, arguments);
  };
}(); // Logout Admin

var logout = function logout() {
  js_cookie__WEBPACK_IMPORTED_MODULE_15___default.a.remove('token'); // To support logging out from all windows

  window.localStorage.setItem('logout', _babel_runtime_corejs2_core_js_date_now__WEBPACK_IMPORTED_MODULE_8___default()());
  next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/login');
}; // Gets the display name of JSX component for dev tools

var getDisplayName = function getDisplayName(Component) {
  return Component.displayName || Component.name || 'Component';
}; // Check if User is Authorized or Not


var withAuthSync = function withAuthSync(WrappedComponent) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_Component) {
    Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__["default"])(_class, _Component);

    Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__["default"])(_class, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
        /*#__PURE__*/
        _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee2(ctx) {
          var token, componentProps;
          return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  token = auth(ctx);
                  _context2.t0 = WrappedComponent.getInitialProps;

                  if (!_context2.t0) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return WrappedComponent.getInitialProps(ctx);

                case 5:
                  _context2.t0 = _context2.sent;

                case 6:
                  componentProps = _context2.t0;
                  return _context2.abrupt("return", Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, componentProps, {
                    token: token
                  }));

                case 8:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        function getInitialProps(_x2) {
          return _getInitialProps.apply(this, arguments);
        }

        return getInitialProps;
      }()
    }]);

    function _class(props) {
      var _this;

      Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, _class);

      _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(_class).call(this, props));
      _this.syncLogout = _this.syncLogout.bind(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(_this));
      return _this;
    }

    Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_5__["default"])(_class, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        window.addEventListener('storage', this.syncLogout);
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        window.removeEventListener('storage', this.syncLogout);
        window.localStorage.removeItem('logout');
      }
    }, {
      key: "syncLogout",
      value: function syncLogout(event) {
        if (event.key === 'logout') {
          next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/login');
        }
      }
    }, {
      key: "render",
      value: function render() {
        return react__WEBPACK_IMPORTED_MODULE_11___default.a.createElement(WrappedComponent, this.props);
      }
    }]);

    return _class;
  }(react__WEBPACK_IMPORTED_MODULE_11__["Component"]), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(_class, "displayName", "withAuthSync(".concat(getDisplayName(WrappedComponent), ")")), _temp;
};
var auth = function auth(ctx) {
  var _nextCookie = next_cookies__WEBPACK_IMPORTED_MODULE_14___default()(ctx),
      token = _nextCookie.token;
  /*
   * This happens on server only, ctx.req is available means it's being
   * rendered on server. If we are on server and token is not available,
   * means user is not logged in.
   */


  if (ctx.req && !token) {
    ctx.res.writeHead(302, {
      location: '/login'
    });
    ctx.res.end();
    return;
  } // We already checked for server. This should only happen in client


  if (!token) {
    next_router__WEBPACK_IMPORTED_MODULE_13___default.a.push('/login');
    return token;
  }
}; // Change Password

var changePassword =
/*#__PURE__*/
function () {
  var _ref3 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee3(id, newPassword, oldPassword) {
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_12___default.a.put("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/admin/restorepass"), {
              userId: id,
              oldPassword: oldPassword,
              newPassword: newPassword
            });

          case 2:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function changePassword(_x3, _x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}(); // Forget Password

var forgetPassword =
/*#__PURE__*/
function () {
  var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.mark(function _callee4(email) {
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_9___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_12___default.a.put("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/admin/forgotpassword"), {
              email: email
            });

          case 2:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function forgetPassword(_x6) {
    return _ref4.apply(this, arguments);
  };
}();

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "St2x":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/AccountCardDetails");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "TWtx":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableHead");

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _inherits; });
/* harmony import */ var _core_js_object_create__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("SqZg");
/* harmony import */ var _core_js_object_create__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_create__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("VLay");


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _core_js_object_create__WEBPACK_IMPORTED_MODULE_0___default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object(_setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(subClass, superClass);
}

/***/ }),

/***/ "UVoM":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Typography");

/***/ }),

/***/ "Uynj":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Container");

/***/ }),

/***/ "VLay":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _setPrototypeOf; });
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0__);

function _setPrototypeOf(o, p) {
  _setPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

/***/ }),

/***/ "W+03":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemText");

/***/ }),

/***/ "Wh1t":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "XXOK":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("J3/a");

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "b5DJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js + 3 modules
var slicedToArray = __webpack_require__("doui");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__("h74D");

// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__("dYMV");
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);

// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__("9Pu4");

// EXTERNAL MODULE: external "@material-ui/core/List"
var List_ = __webpack_require__("0LMq");
var List_default = /*#__PURE__*/__webpack_require__.n(List_);

// EXTERNAL MODULE: external "@material-ui/core/ListItem"
var ListItem_ = __webpack_require__("c25J");
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_);

// EXTERNAL MODULE: external "@material-ui/core/ListItemText"
var ListItemText_ = __webpack_require__("W+03");
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);

// EXTERNAL MODULE: external "@material-ui/core/Dialog"
var Dialog_ = __webpack_require__("fEgT");
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog_);

// EXTERNAL MODULE: external "@material-ui/core/DialogContent"
var DialogContent_ = __webpack_require__("iTUb");
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent_);

// EXTERNAL MODULE: external "@material-ui/core/CircularProgress"
var CircularProgress_ = __webpack_require__("1imS");
var CircularProgress_default = /*#__PURE__*/__webpack_require__.n(CircularProgress_);

// EXTERNAL MODULE: external "@material-ui/core/Grid"
var Grid_ = __webpack_require__("JQ2V");
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);

// EXTERNAL MODULE: external "@material-ui/core/TextField"
var TextField_ = __webpack_require__("IbbU");
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);

// EXTERNAL MODULE: external "@material-ui/core/InputAdornment"
var InputAdornment_ = __webpack_require__("lj8g");
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment_);

// EXTERNAL MODULE: external "@material-ui/core/Button"
var Button_ = __webpack_require__("Wh1t");
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);

// EXTERNAL MODULE: external "@material-ui/core/Typography"
var Typography_ = __webpack_require__("UVoM");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);

// EXTERNAL MODULE: ./translations/arabicTranslation.js
var arabicTranslation = __webpack_require__("4Ioi");

// EXTERNAL MODULE: ./components/DialogTitle.js
var DialogTitle = __webpack_require__("Aet0");

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// CONCATENATED MODULE: ./utils/wallet.js



var getWalletDetails =
/*#__PURE__*/
function () {
  var _ref = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(id) {
    var _ref2, data;

    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return external_axios_default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/order/").concat(id, "/wallet"));

          case 2:
            _ref2 = _context.sent;
            data = _ref2.data;
            return _context.abrupt("return", data);

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function getWalletDetails(_x) {
    return _ref.apply(this, arguments);
  };
}();
var withdrawFromWallet =
/*#__PURE__*/
function () {
  var _ref3 = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee2(adminId, companyId, amount) {
    return regenerator_default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return external_axios_default.a.get("".concat("http://cashback.us-east-2.elasticbeanstalk.com", "/order/").concat(companyId, "/withdrawWallet/").concat(adminId, "/").concat(amount));

          case 2:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function withdrawFromWallet(_x2, _x3, _x4) {
    return _ref3.apply(this, arguments);
  };
}();
// CONCATENATED MODULE: ./redux/actions/loadingActions.js
var loadingActions_startLoading = function startLoading() {
  return {
    type: 'LOADING'
  };
};
var loadingActions_endLoading = function endLoading() {
  return {
    type: 'NOT_LOADING'
  };
};
// CONCATENATED MODULE: ./components/WalletDetails.js























var useStyles = Object(styles_["makeStyles"])(function (theme) {
  return {
    textCentre: {
      textAlign: 'center'
    }
  };
});

var WalletDetails_WalletDetails = function WalletDetails(_ref) {
  var onClose = _ref.onClose,
      open = _ref.open,
      client = _ref.client,
      loading = _ref.loading,
      startLoading = _ref.startLoading,
      endLoading = _ref.endLoading,
      adminId = _ref.adminId;
  var classes = useStyles();

  var _useState = Object(external_react_["useState"])(null),
      _useState2 = Object(slicedToArray["a" /* default */])(_useState, 2),
      wallet = _useState2[0],
      setWallet = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(''),
      _useState4 = Object(slicedToArray["a" /* default */])(_useState3, 2),
      withdraw = _useState4[0],
      setWithdraw = _useState4[1];

  var _useState5 = Object(external_react_["useState"])(''),
      _useState6 = Object(slicedToArray["a" /* default */])(_useState5, 2),
      message = _useState6[0],
      setMessage = _useState6[1];

  var _useState7 = Object(external_react_["useState"])(false),
      _useState8 = Object(slicedToArray["a" /* default */])(_useState7, 2),
      error = _useState8[0],
      setError = _useState8[1];

  Object(external_react_["useEffect"])(function () {
    var fetchData =
    /*#__PURE__*/
    function () {
      var _ref2 = Object(asyncToGenerator["a" /* default */])(
      /*#__PURE__*/
      regenerator_default.a.mark(function _callee() {
        var walletData;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return getWalletDetails(client.companyId);

              case 2:
                walletData = _context.sent;
                setWallet(walletData);

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function fetchData() {
        return _ref2.apply(this, arguments);
      };
    }();

    fetchData();
  }, [client.companyId]);

  var handleWithdraw =
  /*#__PURE__*/
  function () {
    var _ref3 = Object(asyncToGenerator["a" /* default */])(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee2() {
      var walletData;
      return regenerator_default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              startLoading();
              _context2.next = 4;
              return withdrawFromWallet(adminId, client.companyId, withdraw);

            case 4:
              setMessage(arabicTranslation["a" /* default */].WITHDRAW_SUCCESS);
              setWithdraw('');
              _context2.next = 8;
              return getWalletDetails(client.companyId);

            case 8:
              walletData = _context2.sent;
              setWallet(walletData);
              endLoading();
              _context2.next = 18;
              break;

            case 13:
              _context2.prev = 13;
              _context2.t0 = _context2["catch"](0);
              endLoading();
              setMessage(arabicTranslation["a" /* default */].FAILED_WITHDRAW);
              setError(true);

            case 18:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[0, 13]]);
    }));

    return function handleWithdraw() {
      return _ref3.apply(this, arguments);
    };
  }();

  return external_react_default.a.createElement(Dialog_default.a, {
    onClose: onClose,
    open: open,
    maxWidth: "xs",
    fullWidth: true
  }, external_react_default.a.createElement(DialogTitle["a" /* default */], {
    onClose: onClose
  }, client.name), external_react_default.a.createElement(DialogContent_default.a, {
    dividers: true,
    className: external_clsx_default()(Object(defineProperty["a" /* default */])({}, classes.textCentre, !wallet))
  }, !wallet && external_react_default.a.createElement(CircularProgress_default.a, null), wallet && external_react_default.a.createElement(List_default.a, null, external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].TOTAL_PROFIT, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.profit, " SAR")))), !client.isNonProfit && external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].COMISSION, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.commission, " SAR")))), external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].TRANSFERRED_PROFIT, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.transferredProfit, " SAR")))), external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(ListItemText_default.a, {
    style: {
      color: 'red'
    }
  }, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 9
  }, arabicTranslation["a" /* default */].CURRENT_BALANCE, ":"), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 3
  }, wallet.currentBalance, " SAR")))), external_react_default.a.createElement(ListItem_default.a, null, external_react_default.a.createElement(Grid_default.a, {
    container: true,
    spacing: 2
  }, external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 6
  }, external_react_default.a.createElement(Button_default.a, {
    color: "primary",
    variant: "contained",
    disabled: !withdraw || withdraw <= 0 || loading,
    onClick: handleWithdraw
  }, arabicTranslation["a" /* default */].WITHDRAW)), external_react_default.a.createElement(Grid_default.a, {
    item: true,
    sm: 6
  }, external_react_default.a.createElement(TextField_default.a, {
    value: withdraw,
    onChange: function onChange(e) {
      return setWithdraw(e.target.value);
    },
    type: "number",
    InputProps: {
      endAdornment: external_react_default.a.createElement(InputAdornment_default.a, {
        position: "end"
      }, "SAR")
    },
    error: withdraw < 0,
    helperText: withdraw < 0 && arabicTranslation["a" /* default */].LOWER_ZERO
  }))))), message && external_react_default.a.createElement(Typography_default.a, {
    align: "center",
    color: error ? 'error' : 'initial'
  }, message)));
};

var mapStateToProps = function mapStateToProps(state) {
  return {
    loading: state.loading,
    adminId: state.auth.adminId
  };
};

var WalletDetails_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    startLoading: function startLoading() {
      return dispatch(loadingActions_startLoading());
    },
    endLoading: function endLoading() {
      return dispatch(loadingActions_endLoading());
    }
  };
};

/* harmony default export */ var components_WalletDetails = __webpack_exports__["a"] = (Object(external_react_redux_["connect"])(mapStateToProps, WalletDetails_mapDispatchToProps)(WalletDetails_WalletDetails));

/***/ }),

/***/ "bzUq":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TablePagination");

/***/ }),

/***/ "c25J":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItem");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "dYMV":
/***/ (function(module, exports) {

module.exports = require("clsx");

/***/ }),

/***/ "doui":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js

function _arrayWithHoles(arr) {
  if (is_array_default()(arr)) return arr;
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js
var get_iterator = __webpack_require__("XXOK");
var get_iterator_default = /*#__PURE__*/__webpack_require__.n(get_iterator);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = get_iterator_default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _slicedToArray; });



function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "eaXY":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/FileDocument");

/***/ }),

/***/ "eoIS":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Instagram");

/***/ }),

/***/ "fEgT":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Dialog");

/***/ }),

/***/ "fdDk":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Wallet");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "gXGL":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Close");

/***/ }),

/***/ "h74D":
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iDDF":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/TableRow");

/***/ }),

/***/ "iTUb":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogContent");

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "lj8g":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/InputAdornment");

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "mxtS":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/Web");

/***/ }),

/***/ "nFSa":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/City");

/***/ }),

/***/ "ncp3":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/CellphoneAndroid");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p0XB":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("R2Q7");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qt1I":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Paper");

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "vF8F":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Tooltip");

/***/ }),

/***/ "vW2u":
/***/ (function(module, exports) {

module.exports = require("mdi-material-ui/MapMarker");

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vmXh":
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "y6vh":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/date/now");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });